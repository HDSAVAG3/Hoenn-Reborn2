# Hoenn Reborn — GitHub build

This repository is prepared for a cloud build through GitHub Actions.

## Phone-only setup

1. Create a new GitHub repository.
2. Upload the contents of this project ZIP to the repository.
3. Make sure `.github/workflows/build.yml` exists in the default branch.
4. Open the repository's **Actions** tab.
5. Select **Build Hoenn Reborn for Nintendo 3DS**.
6. Choose **Run workflow**.
7. Wait for the build to finish.
8. Open the completed run and download the `Hoenn-Reborn-3DS-Build` artifact.

The workflow builds the mGBA 3DS core first and then builds the Hoenn Reborn 3DSX/CIA.

## 3DS SD card

After downloading the artifact, the expected ROM location is:

    sd:/3ds/Hoenn_Reborn/pokeemerald.gba

The project does not contain or distribute a Pokemon Emerald ROM.

## Important

The first GitHub build is a validation build. If it fails, download the `Hoenn-Reborn-Build-Logs` artifact and use the error output to fix the project. Do not assume a failed build means the 3DS itself is the problem.

## Current target

- New Nintendo 3DS XL
- 400x240 top screen
- 320x240 bottom touchscreen
- mGBA GBA emulation
- New 3DS ZL/ZR and C-stick mappings
