@echo off
setlocal
cd /d "%~dp0.."
call tools\check_env_windows.bat
if errorlevel 1 exit /b 1
if "%MGBA_DIR%"=="" set MGBA_DIR=..\mgba
make clean
make MGBA_DIR="%MGBA_DIR%" -j2
if errorlevel 1 exit /b 1
if not exist dist mkdir dist
copy /Y Hoenn_Reborn.3dsx dist\Hoenn_Reborn.3dsx >nul
copy /Y Hoenn_Reborn.cia dist\Hoenn_Reborn.cia >nul
echo.
echo Build complete. Files are in dist\
endlocal
