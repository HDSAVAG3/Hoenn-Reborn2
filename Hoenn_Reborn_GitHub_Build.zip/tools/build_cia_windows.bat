@echo off
if "%DEVKITPRO%"=="" set DEVKITPRO=C:\devkitPro
if "%DEVKITARM%"=="" set DEVKITARM=%DEVKITPRO%\devkitARM
if "%MGBA_DIR%"=="" set MGBA_DIR=..\mgba
make clean
make MGBA_DIR="%MGBA_DIR%" cia
make MGBA_DIR="%MGBA_DIR%" 3dsx
echo Built Hoenn_Reborn.cia and Hoenn_Reborn.3dsx
