#!/usr/bin/env bash
set -euo pipefail

fail=0
need=(make cmake arm-none-eabi-gcc 3dsxtool bannertool makerom tex3ds)
for c in "${need[@]}"; do
  if command -v "$c" >/dev/null 2>&1; then
    printf '[OK] %s -> %s\n' "$c" "$(command -v "$c")"
  else
    printf '[MISSING] %s\n' "$c"
    fail=1
  fi
done

if [[ -z "${DEVKITPRO:-}" ]]; then echo '[MISSING] DEVKITPRO'; fail=1; else echo "[OK] DEVKITPRO=$DEVKITPRO"; fi
if [[ -z "${DEVKITARM:-}" ]]; then echo '[MISSING] DEVKITARM'; fail=1; else echo "[OK] DEVKITARM=$DEVKITARM"; fi

if [[ ! -f "${MGBA_DIR:-../mgba}/CMakeLists.txt" ]]; then
  echo "[MISSING] mGBA source tree. Set MGBA_DIR to the mGBA checkout."
  fail=1
else
  echo "[OK] mGBA source -> ${MGBA_DIR:-../mgba}"
fi

exit "$fail"
