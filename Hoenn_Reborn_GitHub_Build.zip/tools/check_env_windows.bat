@echo off
setlocal
where arm-none-eabi-gcc >nul 2>&1 || echo [MISSING] arm-none-eabi-gcc
where make >nul 2>&1 || echo [MISSING] make
where cmake >nul 2>&1 || echo [MISSING] cmake
where 3dsxtool >nul 2>&1 || echo [MISSING] 3dsxtool
where bannertool >nul 2>&1 || echo [MISSING] bannertool
where makerom >nul 2>&1 || echo [MISSING] makerom
where tex3ds >nul 2>&1 || echo [MISSING] tex3ds
if "%DEVKITPRO%"=="" echo [MISSING] DEVKITPRO
if "%DEVKITARM%"=="" echo [MISSING] DEVKITARM
if not exist "%~dp0..\..\mgba\CMakeLists.txt" if "%MGBA_DIR%"=="" echo [MISSING] mGBA checkout - set MGBA_DIR
endlocal
