#!/bin/sh
set -eu
export DEVKITPRO="${DEVKITPRO:-/opt/devkitpro}"
export DEVKITARM="${DEVKITARM:-$DEVKITPRO/devkitARM}"
MGBA_DIR="${MGBA_DIR:-../mgba}"
make clean
make MGBA_DIR="$MGBA_DIR" cia
make MGBA_DIR="$MGBA_DIR" 3dsx
echo "Built Hoenn_Reborn.cia and Hoenn_Reborn.3dsx"
