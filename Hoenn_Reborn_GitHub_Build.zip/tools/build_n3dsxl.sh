#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

./tools/check_env.sh

MGBA_DIR="${MGBA_DIR:-../mgba}"
make clean || true
make MGBA_DIR="$MGBA_DIR" -j"$(getconf _NPROCESSORS_ONLN 2>/dev/null || echo 2)"

mkdir -p dist
cp -f Hoenn_Reborn.3dsx dist/Hoenn_Reborn.3dsx
cp -f Hoenn_Reborn.cia dist/Hoenn_Reborn.cia
printf '\nBuild complete. Files are in %s/dist/\n' "$ROOT"
