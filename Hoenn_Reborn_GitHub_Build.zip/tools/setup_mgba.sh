#!/usr/bin/env bash
set -euo pipefail

MGBA_DIR="${1:-../mgba}"
if [[ -d "$MGBA_DIR/.git" ]]; then
  echo "mGBA checkout already exists at $MGBA_DIR"
  exit 0
fi

git clone --depth 1 https://github.com/mgba-emu/mgba.git "$MGBA_DIR"
echo "mGBA cloned to $MGBA_DIR"
