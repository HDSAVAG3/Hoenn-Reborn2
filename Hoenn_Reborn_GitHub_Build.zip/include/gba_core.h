#pragma once
#include <3ds.h>
#include <stdint.h>
#include <stdbool.h>

#define GBA_W 240
#define GBA_H 160

typedef struct {
    uint16_t pixels[GBA_W * GBA_H];
    bool loaded;
    uint32_t rom_size;
} GbaFrame;

typedef struct {
    bool loaded;
    uint32_t rom_size;
    void *backend;
} GbaCore;

bool gba_core_init(GbaCore *core, const char *rom_path);
void gba_core_reset(GbaCore *core);
void gba_core_step(GbaCore *core);
void gba_core_set_input(GbaCore *core, uint16_t buttons);
void gba_core_get_frame(GbaCore *core, GbaFrame *out);
void gba_core_shutdown(GbaCore *core);

/* Lightweight inspection helpers used by the Hoenn Reborn dashboard. */
uint8_t gba_core_bus_read8(GbaCore *core, uint32_t address);
uint16_t gba_core_bus_read16(GbaCore *core, uint32_t address);
uint32_t gba_core_bus_read32(GbaCore *core, uint32_t address);
uint32_t gba_core_frame_counter(GbaCore *core);
bool gba_core_get_game_code(GbaCore *core, char out_code[5]);
bool gba_core_get_game_title(GbaCore *core, char *out_title, unsigned out_size);
