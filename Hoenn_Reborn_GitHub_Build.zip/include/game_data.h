#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "gba_core.h"

#define PARTY_SLOTS 6

typedef struct {
    uint16_t species;
    uint8_t level;
    uint16_t hp;
    uint16_t max_hp;
} PartyMonSnapshot;

typedef struct {
    bool available;
    bool emerald_profile;
    uint32_t frame;
    uint32_t rom_size;
    char game_code[5];
    uint8_t party_count;
    PartyMonSnapshot party[PARTY_SLOTS];
    bool map_available;
    uint16_t map_group;
    uint16_t map_num;
    uint16_t player_x;
    uint16_t player_y;
    bool bag_available;
    uint16_t bag_item_count;
    bool dex_available;
    uint16_t dex_seen;
    uint16_t dex_owned;
} GameDataSnapshot;

void game_data_init(void);
void game_data_update(GbaCore *gba, GameDataSnapshot *out);
