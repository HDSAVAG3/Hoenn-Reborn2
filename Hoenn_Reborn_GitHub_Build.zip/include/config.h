#pragma once
#define APP_NAME "Hoenn Reborn"
#define APP_TITLE "Hoenn Reborn"
#define APP_AUTHOR "Hoenn Reborn"
#define ROM_PATH "sdmc:/3ds/Hoenn_Reborn/pokeemerald.gba"
#define ROM_DIR  "sdmc:/3ds/Hoenn_Reborn"
#define SAVE_PATH "sdmc:/3ds/Hoenn_Reborn/pokeemerald.sav"
#define ROMFS_ROOT "romfs:/hoenn_reborn"
#define TOP_W 400
#define TOP_H 240
#define BOT_W 320
#define BOT_H 240
#define GBA_W 240
#define GBA_H 160
