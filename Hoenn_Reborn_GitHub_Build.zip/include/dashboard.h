#pragma once
#include <3ds.h>
#include <stdbool.h>
#include "game_data.h"

typedef enum {
    PANEL_POKEMON = 0,
    PANEL_BAG,
    PANEL_MAP,
    PANEL_SAVE,
    PANEL_POKEDEX,
    PANEL_OPTIONS,
    PANEL_COUNT
} DashboardPanel;

typedef struct {
    DashboardPanel active;
    bool save_requested;
    bool touch_consumed;
    bool turbo;
    bool panel_action;
} DashboardState;

void dashboard_init(DashboardState *state);
void dashboard_update(DashboardState *state, touchPosition touch, bool touching,
                      u32 held, u32 down);
void dashboard_draw(const DashboardState *state, const GameDataSnapshot *game);
DashboardPanel dashboard_active(const DashboardState *state);
bool dashboard_take_save_request(DashboardState *state);
