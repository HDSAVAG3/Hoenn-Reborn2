#pragma once
#include <stdint.h>

/* Pokémon Emerald USA (BPEE) runtime profile.
 * Keep every build-specific address here so the UI/data layer stays portable.
 * These addresses are only used after the ROM header product code is BPEE. */
#define EMERALD_USA_GAME_CODE "BPEE"
#define EMERALD_PARTY_COUNT_ADDR 0x020244E9u
#define EMERALD_PARTY_ADDR       0x020244ECu
#define EMERALD_PARTY_SIZE       100u
#define EMERALD_PARTY_SPECIES_OFF 32u
#define EMERALD_PARTY_LEVEL_OFF   84u
#define EMERALD_PARTY_HP_OFF      86u
#define EMERALD_PARTY_MAXHP_OFF   88u

/* Gen III save block pointer location in standard Emerald. It is intentionally
 * not dereferenced by the Milestone 5 UI yet; save/map offsets need a profile
 * for the exact ROM build. */
#define EMERALD_SAVE_BLOCK1_PTR_ADDR 0x03005D8Cu
