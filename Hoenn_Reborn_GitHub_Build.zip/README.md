# Hoenn Reborn — New Nintendo 3DS XL

Milestone 6 build/test project for a dual-screen Pokémon Emerald frontend using libctru/Citro2D and the mGBA GBA core.

## Current target

- New Nintendo 3DS / New Nintendo 3DS XL
- Top: 400x240
- Bottom: 320x240 touch
- GBA: mGBA static core
- SD ROM: `/3ds/Hoenn_Reborn/pokeemerald.gba`
- SD save: `/3ds/Hoenn_Reborn/pokeemerald.sav`

## Build prerequisites

Use the current devkitPro 3DS environment with devkitARM/libctru and the 3DS build tools. mGBA provides an official 3DS CMake toolchain at `src/platform/3ds/CMakeToolchain.txt`.

You also need an mGBA checkout. By default the project expects:

```text
Projects/
├── mgba/
└── Hoenn_Reborn_3DS_N3DSXL/
```

## Build

```sh
./tools/check_env.sh
./tools/build_n3dsxl.sh
```

Or set a different mGBA location:

```sh
MGBA_DIR=/path/to/mgba ./tools/build_n3dsxl.sh
```

Windows/MSYS2:

```bat
tools\build_n3dsxl_windows.bat
```

The result is placed in `dist/` as:

- `Hoenn_Reborn.3dsx`
- `Hoenn_Reborn.cia`

## First hardware test

Test the `.3dsx` before installing the CIA. Copy it to:

```text
/3ds/Hoenn_Reborn/Hoenn_Reborn.3dsx
```

and place your own Emerald ROM at:

```text
/3ds/Hoenn_Reborn/pokeemerald.gba
```

## Milestone status

1. Dual-screen shell — complete
2. mGBA integration boundary — complete
3. Touch dashboard — complete
4. Live game-data bridge — complete
5. Profile-gated Emerald party data — complete
6. Reproducible N3DSXL build/test workflow — complete
7. Hardware validation and verified Bag/Map/Pokédex/save adapters — next

See `docs/MILESTONE6.md` for the hardware checklist.


## Milestone 7 — New 3DS XL input validation

The frontend now maps ZL/ZR to GBA L/R and the New 3DS C-stick to the GBA D-pad. The primary ROM location is:

`sdmc:/3ds/Hoenn_Reborn/pokeemerald.gba`

Test the `.3dsx` first through Homebrew Launcher. Only package/install the CIA after the `.3dsx` boots and the ROM loads correctly.


## GitHub cloud build

See `GITHUB_BUILD.md`. The repository includes `.github/workflows/build.yml` for a cloud build using the devkitPro devkitARM container. The first run is intended to validate the current source and mGBA integration; any failure logs are uploaded as a workflow artifact.
