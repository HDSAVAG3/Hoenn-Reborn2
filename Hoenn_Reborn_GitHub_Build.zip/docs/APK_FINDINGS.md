# APK inspection notes

The supplied APK was inspected as an Android ZIP/APK.

## Native binaries
`lib/armeabi-v7a/libmain.so`:
- ELF 32-bit ARM shared object
- Android NDK r26d / Clang 17 metadata
- dynamically linked against Android `libc`, `libm`, `libdl`, OpenGL ES `libGLESv1_CM`, and `libSDL2`
- about 20.3 MiB

`lib/armeabi-v7a/libSDL2.so` is also present.

## Game-engine evidence
The native library exports a large set of Pokémon Emerald symbols such as map layouts, event scripts, battle functions, save functions, Pokédex data, and menu strings. It also contains strings for:
- `pokeemerald.gba`
- `pokeemerald.sav`
- `pokeemerald.cfg`
- `asset_manifest.bin`
- SDL touch/mouse events
- SDL renderer/texture/window initialization

This strongly indicates the APK is a native SDL-based Pokémon Emerald build rather than a simple Java wrapper.

## Supplied visual assets
- `BG.png`: 1280x720 RGBA
- `BG1.png`: 1280x720 RGBA
- `Border.png`: 1280x720 RGBA
- `asset_manifest.bin`

The 3DS project copies those assets into RomFS. The Android ELF itself is intentionally not reused because its ABI and dependencies are not compatible with Nintendo 3DS.
