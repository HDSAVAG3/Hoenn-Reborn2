# Milestone 5 — Live panel framework + validated Emerald party data

This milestone turns the dashboard into a real panel surface and makes the Pokémon panel read live data from the running mGBA core.

## Live now

- ROM product-code detection (`BPEE` for Pokémon Emerald USA).
- Party count from Emerald runtime RAM.
- Species ID for each party slot.
- Level, current HP and max HP for each party slot.
- Live frame counter.
- Bottom-screen panel-specific views for Pokémon, Bag, Map, Save, Pokédex and Options.
- No guessed Bag/Map/Pokédex offsets are displayed as real data.

mGBA's public `mCore` API provides frame execution, game information, and bus reads, which is why the adapter stays outside the UI layer.

## Important

The project does **not** yet claim full Bag/Map/Pokédex support. Those fields depend on the exact Emerald build or ROM-hack symbol map. The profile is isolated in `include/emerald_profile.h` so a known build can be added without rewriting the dashboard.

## Save behavior

The Save panel currently provides guidance rather than forcing an emulator shutdown/reload. This avoids resetting gameplay just to flush a save. A later milestone should add a proper mGBA savedata flush API if the selected mGBA revision exposes one cleanly for the 3DS build.

## Next

Milestone 6 should focus on:

1. Build against an actual devkitPro/devkitARM + mGBA checkout.
2. Test the BPEE party adapter with a real user-supplied Emerald ROM/save.
3. Add a profile/symbol map for the user's specific Hoenn Reborn build.
4. Implement Bag, Map and Pokédex offsets from verified symbols.
5. Finish CIA metadata and install/test on New 3DS XL.
