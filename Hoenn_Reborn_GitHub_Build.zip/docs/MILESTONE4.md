# Milestone 4 — Live game-data dashboard bridge

This milestone connects the touchscreen shell to mGBA's public `mCore` bus-read API.

## Added

- `game_data.c/.h`: isolated Emerald runtime-data adapter.
- Public mGBA bus-read wrappers in `gba_core.h`.
- Dashboard panel-specific status text.
- Pokémon panel reports party count when the expected Emerald RAM location is valid.
- Save panel triggers the emulator shutdown/reload path already present in the frontend.
- No ROM or save data is bundled.

## Important compatibility note

The party-count address used here is for the standard Pokémon Emerald USA runtime. A ROM hack or different regional/build revision can relocate globals. The adapter is deliberately isolated so those addresses can be replaced by a symbol map or build-specific profile later.

## Next milestone

Milestone 5 should add a **ROM/build profile** and real data adapters for:

1. party species/names/levels,
2. bag pockets,
3. map group/number and coordinates,
4. Pokédex seen/owned,
5. a real save/export operation.

Do not treat the dashboard as a second independent game state: it should always read the running emulator state.
