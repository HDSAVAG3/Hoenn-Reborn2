# Milestone 6 — New 3DS XL build/test stage

This milestone makes the project ready for a real devkitPro + devkitARM build. mGBA currently documents a dedicated 3DS CMake toolchain, and libctru is the supported 3DS user-mode library foundation.

## 1. Install the 3DS development environment

Install the current devkitPro 3DS environment, including devkitARM/libctru and the 3DS build tools. Ensure `arm-none-eabi-gcc`, `3dsxtool`, `bannertool`, `makerom`, and `tex3ds` are available in PATH.

## 2. Get mGBA

From the parent Projects directory:

```sh
./Hoenn_Reborn_3DS_N3DSXL/tools/setup_mgba.sh ../mgba
```

Or clone mGBA yourself. The project expects `MGBA_DIR=../mgba` by default.

## 3. Build

Linux/macOS/MSYS2:

```sh
cd Hoenn_Reborn_3DS_N3DSXL
./tools/build_n3dsxl.sh
```

Windows/MSYS2:

```bat
tools\build_n3dsxl_windows.bat
```

The build first configures mGBA with its official 3DS toolchain and then links the static mGBA core into Hoenn Reborn.

## 4. Test the 3DSX first

Copy `dist/Hoenn_Reborn.3dsx` to:

```text
/3ds/Hoenn_Reborn/Hoenn_Reborn.3dsx
```

Put your own ROM at:

```text
/3ds/Hoenn_Reborn/pokeemerald.gba
```

Launch it from Homebrew Launcher. This is the safest first hardware test before installing the CIA.

## 5. CIA

After the 3DSX works, copy `dist/Hoenn_Reborn.cia` to the SD card and install it with the user's preferred homebrew CIA installer. A CIA is an installable homebrew package; the target system must already be configured to run unsigned homebrew.

## Hardware test checklist

- New 3DS XL boots without crash
- Top screen renders 400x240 UI
- GBA image remains 3:2 and centered
- Bottom touchscreen registers taps
- A/B/D-pad/L/R reach the GBA core
- X/Y and ZL/ZR change dashboard panels
- Emerald boots from `/3ds/Hoenn_Reborn/pokeemerald.gba`
- Existing `.sav` loads if present
- In-game save survives a clean exit
- Sleep/wake and Home-menu behavior do not corrupt the emulator state

## Important

The project does not include a Pokémon Emerald ROM. Use your own legally obtained copy. The dashboard's game-data adapters are profile-gated and should not display guessed Bag/Map/Pokédex data for unknown ROM builds.


## Milestone 7 changes

- New 3DS ZL/ZR are mapped to GBA L/R.
- New 3DS C-stick directions are mapped to GBA D-pad directions.
- Added the SD root directory constant for future file/ROM discovery.
- The primary ROM path remains `sdmc:/3ds/Hoenn_Reborn/pokeemerald.gba`.
- This milestone is intended for first hardware validation before implementing more build-specific game-data offsets.
