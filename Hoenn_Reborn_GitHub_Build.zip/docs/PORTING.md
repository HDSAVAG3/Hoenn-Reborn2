# Porting status

## Milestone 2 — mGBA backend

The diagnostic GBA stub has been replaced with a real mGBA adapter in `source/gba_core_mgba.c`.

The adapter:

1. Creates an `mPLATFORM_GBA` core.
2. Initializes the core and its configuration.
3. Supplies a native 240x160 RGB565 framebuffer.
4. Loads `sdmc:/3ds/Hoenn_Reborn/pokeemerald.gba`.
5. Attempts to load `sdmc:/3ds/Hoenn_Reborn/pokeemerald.sav`.
6. Maps the 3DS controls to the GBA A/B/Start/Select/D-pad/L/R inputs.
7. Runs one GBA frame per frontend loop.
8. Copies the mGBA framebuffer into the frontend's `GbaFrame` structure.

mGBA's own 3DS frontend uses the same core concepts: a 240x160 GBA video buffer, 3DS input mapping, and `core->runFrame()`/video-buffer based rendering. The official mGBA build system also exposes a 3DS CMake toolchain.

## Current limitation

This environment does not contain devkitARM/devkitPro or the mGBA checkout, so the final CIA cannot be compiled here. The supplied build now performs the actual mGBA build as a prerequisite when run on a properly configured 3DS development machine.

## Next milestone

Render the 240x160 mGBA framebuffer into a Citra/Citro2D texture on the top screen, while preserving the APK-derived bottom-screen dashboard. Then wire dashboard actions such as Save, Bag, Map, Pokédex and Options to the appropriate frontend/emulator behavior.
