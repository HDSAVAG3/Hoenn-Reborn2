# Milestone 3 — Interactive dual-screen shell

This milestone turns the bottom-screen dashboard into an input-driven shell around the mGBA core.

## Implemented

- Touch selection of all six dashboard panels.
- X/Y and ZL/ZR panel cycling on New 3DS XL.
- Preserved 3:2 GBA aspect ratio on the 400x240 top screen (360x240 viewport centered).
- Panel labels rendered on the touchscreen.
- Save panel requests a clean emulator flush/reopen cycle.
- SELECT toggles a frontend turbo flag for future frame pacing work.

## Current limitation

The six panels are frontend placeholders; they do not yet read or modify Pokémon save/RAM structures. The `Save` action is intentionally conservative until explicit mGBA savedata write APIs are wired into the 3DS build.

mGBA exposes the public `mCore` interface for frame execution, keys, video buffers, ROM loading, and save loading; its current source also documents a dedicated 3DS CMake toolchain. citeturn3view0turn0search1

## Next milestone

Milestone 4 should add:

1. explicit cartridge-save writeback,
2. panel-specific UI state,
3. map/Pokédex/party views backed by the game's data,
4. audio output and frame pacing,
5. New 3DS performance profiling.
