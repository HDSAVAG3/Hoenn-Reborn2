#include "game_data.h"
#include "emerald_profile.h"
#include <string.h>
#include <stdio.h>

static uint8_t rd8(GbaCore *gba, uint32_t address) { return gba_core_bus_read8(gba, address); }
static uint16_t rd16(GbaCore *gba, uint32_t address) { return gba_core_bus_read16(gba, address); }

void game_data_init(void) {}

void game_data_update(GbaCore *gba, GameDataSnapshot *out) {
    memset(out, 0, sizeof(*out));
    if (!gba || !gba->loaded) return;

    out->frame = gba_core_frame_counter(gba);
    out->rom_size = gba->rom_size;
    gba_core_get_game_code(gba, out->game_code);
    out->available = true;
    out->emerald_profile = strcmp(out->game_code, EMERALD_USA_GAME_CODE) == 0;

    /* Do not read build-specific globals unless the ROM identifies as BPEE. */
    if (!out->emerald_profile) return;

    uint8_t count = rd8(gba, EMERALD_PARTY_COUNT_ADDR);
    if (count > PARTY_SLOTS) return;
    out->party_count = count;

    for (uint8_t i = 0; i < count; ++i) {
        uint32_t base = EMERALD_PARTY_ADDR + (uint32_t)i * EMERALD_PARTY_SIZE;
        out->party[i].species = rd16(gba, base + EMERALD_PARTY_SPECIES_OFF);
        out->party[i].level = rd8(gba, base + EMERALD_PARTY_LEVEL_OFF);
        out->party[i].hp = rd16(gba, base + EMERALD_PARTY_HP_OFF);
        out->party[i].max_hp = rd16(gba, base + EMERALD_PARTY_MAXHP_OFF);
    }
}
