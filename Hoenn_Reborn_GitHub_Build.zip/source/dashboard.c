#include "dashboard.h"
#include <citro2d.h>
#include <stdio.h>

static const char *names[PANEL_COUNT] = {
    "Pokemon", "Bag", "Map", "Save", "Pokedex", "Options"
};

void dashboard_init(DashboardState *s) {
    *s = (DashboardState){ .active = PANEL_POKEMON, .turbo = false };
}

DashboardPanel dashboard_active(const DashboardState *s) { return s->active; }

bool dashboard_take_save_request(DashboardState *s) {
    bool r = s->save_requested;
    s->save_requested = false;
    return r;
}

static void select_panel(DashboardState *s, int i) {
    if (i < 0 || i >= PANEL_COUNT) return;
    s->active = (DashboardPanel)i;
    s->panel_action = true;
    if (s->active == PANEL_SAVE) s->save_requested = true;
}

void dashboard_update(DashboardState *s, touchPosition t, bool touching, u32 held, u32 down) {
    s->touch_consumed = false;
    s->panel_action = false;
    (void)held;

    if (down & (KEY_X | KEY_ZR)) select_panel(s, ((int)s->active + 1) % PANEL_COUNT);
    if (down & (KEY_Y | KEY_ZL)) select_panel(s, ((int)s->active + PANEL_COUNT - 1) % PANEL_COUNT);
    if (down & KEY_SELECT) s->turbo = !s->turbo;

    if (touching) {
        int col = t.px >= 160 ? 1 : 0;
        int row = t.py / 60;
        int idx = row * 2 + col;
        if (idx >= 0 && idx < PANEL_COUNT) {
            select_panel(s, idx);
            s->touch_consumed = true;
        }
    }
}

void dashboard_draw(const DashboardState *s, const GameDataSnapshot *g) {
    for (int i = 0; i < PANEL_COUNT; ++i) {
        int col = i & 1, row = i >> 1;
        float x = 8 + col * 156, y = 6 + row * 58;
        u32 c = i == s->active ? C2D_Color32(36,132,210,255) : C2D_Color32(30,42,54,255);
        C2D_DrawRectSolid(x, y, 0, 146, 54, c);
    }
    (void)names;
    (void)g;
}
