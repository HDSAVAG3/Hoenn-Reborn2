#include "gba_core.h"
#include "config.h"

#include <mgba/core/core.h>
#include <mgba/core/config.h>
#include <mgba/internal/gba/input.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct GbaCoreImpl {
    struct mCore *core;
    uint16_t video[GBA_W * GBA_H];
    bool loaded;
    uint32_t rom_size;
};

static struct GbaCoreImpl *impl(GbaCore *core) {
    return (struct GbaCoreImpl *)core->backend;
}

bool gba_core_init(GbaCore *core, const char *rom_path) {
    memset(core, 0, sizeof(*core));

    struct GbaCoreImpl *p = calloc(1, sizeof(*p));
    if (!p) return false;

    p->core = mCoreCreate(mPLATFORM_GBA);
    if (!p->core) {
        free(p);
        return false;
    }

    if (!p->core->init(p->core)) {
        p->core->deinit(p->core);
        free(p);
        return false;
    }

    /* With COLOR_16_BIT/COLOR_5_6_5, mColor is a 16-bit RGB565 pixel. */
    p->core->setVideoBuffer(p->core, p->video, GBA_W);

    mCoreInitConfig(p->core, NULL);

    if (!mCoreLoadFile(p->core, rom_path)) {
        mCoreConfigDeinit(&p->core->config);
        p->core->deinit(p->core);
        free(p);
        return false;
    }

    /* Try the normal .sav next to the ROM. Missing save data is harmless. */
    (void)mCoreLoadSaveFile(p->core, SAVE_PATH, false);

    p->core->reset(p->core);
    p->loaded = true;
    p->rom_size = (uint32_t)p->core->romSize(p->core);

    core->backend = p;
    core->loaded = p->loaded;
    core->rom_size = p->rom_size;
    return true;
}

void gba_core_reset(GbaCore *core) {
    struct GbaCoreImpl *p = impl(core);
    if (p && p->core) p->core->reset(p->core);
}

void gba_core_step(GbaCore *core) {
    struct GbaCoreImpl *p = impl(core);
    if (p && p->core && p->loaded) p->core->runFrame(p->core);
}

void gba_core_set_input(GbaCore *core, uint16_t buttons) {
    struct GbaCoreImpl *p = impl(core);
    if (!p || !p->core) return;

    uint32_t keys = 0;
    if (buttons & (1u << 0)) keys |= (1u << GBA_KEY_A);
    if (buttons & (1u << 1)) keys |= (1u << GBA_KEY_B);
    if (buttons & (1u << 2)) keys |= (1u << GBA_KEY_SELECT);
    if (buttons & (1u << 3)) keys |= (1u << GBA_KEY_START);
    if (buttons & (1u << 4)) keys |= (1u << GBA_KEY_RIGHT);
    if (buttons & (1u << 5)) keys |= (1u << GBA_KEY_LEFT);
    if (buttons & (1u << 6)) keys |= (1u << GBA_KEY_UP);
    if (buttons & (1u << 7)) keys |= (1u << GBA_KEY_DOWN);
    if (buttons & (1u << 8)) keys |= (1u << GBA_KEY_R);
    if (buttons & (1u << 9)) keys |= (1u << GBA_KEY_L);

    p->core->setKeys(p->core, keys);
}

void gba_core_get_frame(GbaCore *core, GbaFrame *out) {
    memset(out, 0, sizeof(*out));
    struct GbaCoreImpl *p = impl(core);
    if (!p) return;

    out->loaded = p->loaded;
    out->rom_size = p->rom_size;
    memcpy(out->pixels, p->video, sizeof(out->pixels));
}

void gba_core_shutdown(GbaCore *core) {
    struct GbaCoreImpl *p = impl(core);
    if (!p) return;

    if (p->core) {
        /* mGBA's core owns the cartridge save state and flushes it during teardown. */
        mCoreConfigDeinit(&p->core->config);
        p->core->deinit(p->core);
    }

    free(p);
    memset(core, 0, sizeof(*core));
}


uint8_t gba_core_bus_read8(GbaCore *core, uint32_t address) {
    struct GbaCoreImpl *p = impl(core);
    if (!p || !p->core || !p->loaded) return 0;
    return (uint8_t)p->core->busRead8(p->core, address);
}

uint16_t gba_core_bus_read16(GbaCore *core, uint32_t address) {
    struct GbaCoreImpl *p = impl(core);
    if (!p || !p->core || !p->loaded) return 0;
    return (uint16_t)p->core->busRead16(p->core, address);
}

uint32_t gba_core_bus_read32(GbaCore *core, uint32_t address) {
    struct GbaCoreImpl *p = impl(core);
    if (!p || !p->core || !p->loaded) return 0;
    return p->core->busRead32(p->core, address);
}

uint32_t gba_core_frame_counter(GbaCore *core) {
    struct GbaCoreImpl *p = impl(core);
    if (!p || !p->core || !p->loaded) return 0;
    return p->core->frameCounter(p->core);
}


bool gba_core_get_game_code(GbaCore *core, char out_code[5]) {
    struct GbaCoreImpl *p = impl(core);
    if (!out_code) return false;
    memset(out_code, 0, 5);
    if (!p || !p->core || !p->loaded) return false;
    struct mGameInfo info;
    p->core->getGameInfo(p->core, &info);
    if (!info.code[0]) return false;
    strncpy(out_code, info.code, 4);
    out_code[4] = '\0';
    return true;
}

bool gba_core_get_game_title(GbaCore *core, char *out_title, unsigned out_size) {
    struct GbaCoreImpl *p = impl(core);
    if (!out_title || out_size == 0) return false;
    out_title[0] = '\0';
    if (!p || !p->core || !p->loaded) return false;
    struct mGameInfo info;
    p->core->getGameInfo(p->core, &info);
    if (!info.title[0]) return false;
    snprintf(out_title, out_size, "%s", info.title);
    return true;
}
