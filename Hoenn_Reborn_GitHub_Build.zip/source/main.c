#include <3ds.h>
#include <citro2d.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include "config.h"
#include "gba_core.h"
#include "dashboard.h"
#include "game_data.h"

static C2D_TextBuf textBuf;
static C2D_Text topText, botText;
static C2D_Font sysFont;
static C2D_Image bgImage;
static C2D_Image bg1Image;
static C2D_Image borderImage;
static DashboardState dashboard;

/* A 256x256 RGB565 texture is used because PICA200 textures use power-of-two sizes. */
static C3D_Tex gbaTex;
static Tex3DS_SubTexture gbaSubTex;
static C2D_Image gbaImage;
static uint16_t *gbaTextureBuffer;
static GbaFrame gbaFrame;
static GameDataSnapshot gameData;

static bool load_image(C2D_Image *out, const char *path) {
    C2D_SpriteSheet sheet = C2D_SpriteSheetLoad(path);
    if (!sheet) return false;
    C2D_Image img = C2D_SpriteSheetGetImage(sheet, 0);
    if (!img.tex) return false;
    *out = img;
    return true;
}

static void draw_text(C2D_Text *t, C2D_TextBuf b, float x, float y, const char *s) {
    C2D_TextClear(b);
    C2D_TextParse(t, b, sysFont, s);
    C2D_TextOptimize(t);
    C2D_DrawText(t, C2D_WithColor, x, y, 0.0f, 0.55f, 0.55f, C2D_Color32(255,255,255,255));
}

static bool init_gba_texture(void) {
    gbaTextureBuffer = (uint16_t *)linearAlloc(256 * 256 * sizeof(uint16_t));
    if (!gbaTextureBuffer) return false;
    memset(gbaTextureBuffer, 0, 256 * 256 * sizeof(uint16_t));

    if (!C3D_TexInit(&gbaTex, 256, 256, GPU_RGB565)) return false;
    C3D_TexSetFilter(&gbaTex, GPU_NEAREST, GPU_NEAREST);
    C3D_TexSetWrap(&gbaTex, GPU_CLAMP_TO_EDGE, GPU_CLAMP_TO_EDGE);

    /* Texture coordinates are vertically flipped in the native 3DS texture layout. */
    memset(&gbaSubTex, 0, sizeof(gbaSubTex));
    gbaSubTex.width = GBA_W;
    gbaSubTex.height = GBA_H;
    gbaSubTex.left = 0.0f;
    gbaSubTex.right = (float)GBA_W / 256.0f;
    gbaSubTex.top = 1.0f;
    gbaSubTex.bottom = 1.0f - ((float)GBA_H / 256.0f);

    gbaImage.tex = &gbaTex;
    gbaImage.subtex = &gbaSubTex;
    return true;
}

static void upload_gba_frame(const GbaFrame *frame) {
    if (!gbaTextureBuffer || !frame->loaded) return;

    /* Clear the texture, then place the 240x160 GBA image in its upper-left area. */
    memset(gbaTextureBuffer, 0, 256 * 256 * sizeof(uint16_t));
    for (int y = 0; y < GBA_H; ++y) {
        memcpy(&gbaTextureBuffer[y * 256], &frame->pixels[y * GBA_W], GBA_W * sizeof(uint16_t));
    }

    GSPGPU_FlushDataCache(gbaTextureBuffer, 256 * 256 * sizeof(uint16_t));
    GX_DisplayTransfer(
        (u32 *)gbaTextureBuffer,
        GX_BUFFER_DIM(256, 256),
        gbaTex.data,
        GX_BUFFER_DIM(256, 256),
        GX_TRANSFER_OUT_FORMAT(GX_TRANSFER_FMT_RGB565) |
        GX_TRANSFER_IN_FORMAT(GX_TRANSFER_FMT_RGB565) |
        GX_TRANSFER_OUT_TILED(1) |
        GX_TRANSFER_FLIP_VERT(0));
    gspWaitForPSC0();
}

int main(void) {
    gfxInitDefault();
    gfxSet3D(false);
    romfsInit();

    C3D_Init(C3D_DEFAULT_CMDBUF_SIZE);
    C2D_Init(C2D_DEFAULT_MAX_OBJECTS);
    C2D_Prepare();

    C3D_RenderTarget *top = C2D_CreateScreenTarget(GFX_TOP, GFX_LEFT);
    C3D_RenderTarget *bottom = C2D_CreateScreenTarget(GFX_BOTTOM, GFX_LEFT);
    textBuf = C2D_TextBufNew(4096);
    sysFont = C2D_FontLoadSystem(CFG_REGION_USA);

    load_image(&bgImage, ROMFS_ROOT "/BG.t3x");
    load_image(&bg1Image, ROMFS_ROOT "/BG1.t3x");
    load_image(&borderImage, ROMFS_ROOT "/Border.t3x");
    init_gba_texture();

    dashboard_init(&dashboard);
    game_data_init();

    GbaCore gba;
    bool romOK = gba_core_init(&gba, ROM_PATH);
    (void)romOK;

    while (aptMainLoop()) {
        hidScanInput();
        u32 kDown = hidKeysDown();
        u32 kHeld = hidKeysHeld();
        if (kDown & KEY_START) break;

        touchPosition touch;
        hidTouchRead(&touch);
        dashboard_update(&dashboard, touch, (kHeld & KEY_TOUCH) != 0, kHeld, kDown);

        uint16_t gbaButtons = 0;
        if (kHeld & KEY_A) gbaButtons |= (1u << 0);
        if (kHeld & KEY_B) gbaButtons |= (1u << 1);
        if (kHeld & KEY_SELECT) gbaButtons |= (1u << 2);
        if (kHeld & KEY_START) gbaButtons |= (1u << 3);
        if (kHeld & KEY_RIGHT) gbaButtons |= (1u << 4);
        if (kHeld & KEY_LEFT) gbaButtons |= (1u << 5);
        if (kHeld & KEY_UP) gbaButtons |= (1u << 6);
        if (kHeld & KEY_DOWN) gbaButtons |= (1u << 7);
        if (kHeld & (KEY_R | KEY_ZR)) gbaButtons |= (1u << 8);
        if (kHeld & (KEY_L | KEY_ZL)) gbaButtons |= (1u << 9);

        /* New 3DS C-stick acts as an alternate D-pad. */
        if (kHeld & KEY_CSTICK_RIGHT) gbaButtons |= (1u << 4);
        if (kHeld & KEY_CSTICK_LEFT)  gbaButtons |= (1u << 5);
        if (kHeld & KEY_CSTICK_UP)    gbaButtons |= (1u << 6);
        if (kHeld & KEY_CSTICK_DOWN)  gbaButtons |= (1u << 7);

        gba_core_set_input(&gba, gbaButtons);
        gba_core_step(&gba);
        gba_core_get_frame(&gba, &gbaFrame);
        game_data_update(&gba, &gameData);
        upload_gba_frame(&gbaFrame);

        (void)dashboard_take_save_request(&dashboard);

        C3D_FrameBegin(C3D_FRAME_SYNCDRAW);

        C2D_TargetClear(top, C2D_Color32(8,16,28,255));
        C2D_SceneBegin(top);
        if (bgImage.tex) C2D_DrawImageAt(bgImage, 0, 0, 0, NULL);

        if (gbaFrame.loaded) {
            /* Preserve the GBA 3:2 aspect ratio: 360x240 centered on the
               400x240 New 3DS XL top screen. */
            C2D_DrawImageAt(gbaImage, 20.0f, 0.0f, 0.1f, NULL,
                            1.5f, 1.5f);
        } else {
            C2D_DrawRectSolid(40, 70, 0.1f, 320, 100, C2D_Color32(0,0,0,230));
            draw_text(&topText, textBuf, 72, 92, "Put pokeemerald.gba on SD");
            draw_text(&topText, textBuf, 72, 118, "/3ds/Hoenn_Reborn/");
        }

        if (gbaFrame.loaded) {
            char info[64];
            snprintf(info, sizeof(info), "Hoenn Reborn  |  ROM: %lu KB", (unsigned long)(gbaFrame.rom_size / 1024));
            draw_text(&topText, textBuf, 6, 4, info);
        }

        C2D_TargetClear(bottom, C2D_Color32(14,20,28,255));
        C2D_SceneBegin(bottom);
        if (bg1Image.tex) C2D_DrawImageAt(bg1Image, 0, 0, 0, NULL);
        dashboard_draw(&dashboard, &gameData);

        const char *active = "Pokemon";
        switch (dashboard_active(&dashboard)) {
            case PANEL_BAG: active = "Bag"; break;
            case PANEL_MAP: active = "Map"; break;
            case PANEL_SAVE: active = "Save"; break;
            case PANEL_POKEDEX: active = "Pokedex"; break;
            case PANEL_OPTIONS: active = "Options"; break;
            default: break;
        }

        const char *labels[] = {"Pokemon", "Bag", "Map", "Save", "Pokedex", "Options"};
        for (int i = 0; i < PANEL_COUNT; ++i) {
            int col = i & 1, row = i >> 1;
            draw_text(&botText, textBuf, 18.0f + col * 156.0f,
                      20.0f + row * 58.0f, labels[i]);
        }

        draw_text(&botText, textBuf, 12, 182, active);
        char line[128];
        switch (dashboard_active(&dashboard)) {
            case PANEL_POKEMON:
                if (!gbaFrame.loaded) {
                    snprintf(line, sizeof(line), "Waiting for Emerald ROM");
                    draw_text(&botText, textBuf, 12, 200, line);
                } else if (!gameData.emerald_profile) {
                    snprintf(line, sizeof(line), "ROM code %s (profile expects BPEE)", gameData.game_code);
                    draw_text(&botText, textBuf, 12, 200, line);
                } else {
                    snprintf(line, sizeof(line), "Party %u/6   Frame %lu",
                             (unsigned)gameData.party_count,
                             (unsigned long)gameData.frame);
                    draw_text(&botText, textBuf, 12, 200, line);
                    for (unsigned i = 0; i < gameData.party_count && i < 3; ++i) {
                        snprintf(line, sizeof(line), "%u  Species #%u  Lv%u  HP %u/%u",
                                 i + 1, (unsigned)gameData.party[i].species,
                                 (unsigned)gameData.party[i].level,
                                 (unsigned)gameData.party[i].hp,
                                 (unsigned)gameData.party[i].max_hp);
                        draw_text(&botText, textBuf, 12, 214 + i * 9, line);
                    }
                }
                break;
            case PANEL_BAG:
                draw_text(&botText, textBuf, 12, 200, "Bag adapter: build-specific");
                draw_text(&botText, textBuf, 12, 216, "No guessed save offsets are used.");
                break;
            case PANEL_MAP:
                draw_text(&botText, textBuf, 12, 200, "Map adapter: build-specific");
                draw_text(&botText, textBuf, 12, 216, "Map coordinates are not guessed.");
                break;
            case PANEL_SAVE:
                draw_text(&botText, textBuf, 12, 200, "Use Emerald's in-game Save menu.");
                draw_text(&botText, textBuf, 12, 216, "Dashboard save export is staged next.");
                break;
            case PANEL_POKEDEX:
                draw_text(&botText, textBuf, 12, 200, "Pokedex adapter: build-specific");
                draw_text(&botText, textBuf, 12, 216, "Seen/owned bitsets need profile offsets.");
                break;
            case PANEL_OPTIONS:
                snprintf(line, sizeof(line), "Turbo: %s", dashboard.turbo ? "ON" : "OFF");
                draw_text(&botText, textBuf, 12, 200, line);
                draw_text(&botText, textBuf, 12, 216, "SELECT toggles turbo; X/Y changes panel.");
                break;
            default: break;
        }
        draw_text(&botText, textBuf, 12, 232, "Touch | X/Y | ZL/ZR | C-stick");

        C3D_FrameEnd(0);
    }

    gba_core_shutdown(&gba);
    if (gbaTextureBuffer) linearFree(gbaTextureBuffer);
    C3D_TexDelete(&gbaTex);
    C2D_FontFree(sysFont);
    C2D_TextBufDelete(textBuf);
    C2D_Fini();
    C3D_Fini();
    romfsExit();
    gfxExit();
    return 0;
}
